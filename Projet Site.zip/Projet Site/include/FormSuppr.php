<form class="changement" action="prestation.php" method="post">
  <legend class="modif"> Veuillez écrire le Code TYPE prestation de la prestation à supprimer : </legend>
  <div class="center">
    <input class="remonter" type='text' name='truc'>
  </div>
  <input class ='bouton' type='submit' name='suppr' value='Supprimer'>
</form>
