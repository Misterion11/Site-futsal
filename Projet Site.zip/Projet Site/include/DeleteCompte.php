<form action="profil.php" method="post">
  <legend class='modif'>Voulez-vous vraiment supprimer votre compte ? </legend>
  <table>
    <tr class='modif'>
      <td> <input class='bouton' type="submit" name="deleted" value="Oui"></td>
      <td> <input class='bouton' type="submit" name="keep" value="Non"></td>
    </tr>
  </table>
</form>
