<form class="changement" action="reserver.php" method="post">
  <legend class='modif'>Veuillez remplir les champs pour vous inscrire : </legend>
  <table class=''>
    <tr class='modif'>
      <td>Code de la prestation :<input type="text" name="codeprest" maxlength="8"></td>
      <td>Date de la séance : <input type="date" name="datesea" value="" maxlength="5"></td>
      <td>Nombre de joueurs : <input type="text" name="nbjoueur" value=""></td>
    </tr>
  </table>
  <div class="center">
    <input class="bouton" type="submit" name="valid" value="Valider">
  </div>

</form>
