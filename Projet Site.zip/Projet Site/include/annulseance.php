<form class="changement" action="reserver.php" method="post">
  <legend class="modif">Quelle séance voulez-vous annuler ?</legend>
    <table>
      <tr class="modif">
        <td>Code Prestation : <input type="text" name="CodeAnn" value=""></td>
        <td>Date Séance : <input type="date" name="datean" value=""></td>
      </tr>
    </table>
    <div class="center">
      <input class='bouton' type="submit" name="seanceavoid" value="Valider">
    </div>
  </form>
