<form class="formchang" action="profil.php" method="post">
<table class="tabmodif">
  <tr class="modif">
        <td>Votre ancien pseudo : <input type="text" name="pseudo" maxlength="8" required></td>
        <td>Votre nouveau pseudo :  <input type="text" name="newpseudo" maxlength="8" required></td>
  </tr>
  <tr class='modif'>
    <td colspan="2">
  <input class="bouton" type="submit" name="submit" value="Changer">
    </td>
  </tr>
  </table>
</form>
</div>
